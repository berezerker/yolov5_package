# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['yolov5_hse']

package_data = \
{'': ['*']}

install_requires = \
['Pillow==9.1.0',
 'black>=22.3.0,<23.0.0',
 'numpy==1.22.3',
 'opencv_python==4.5.5.64',
 'pre-commit>=2.18.1,<3.0.0',
 'pylint>=2.13.7,<3.0.0',
 'tensorflow==2.9.0']

entry_points = \
{'console_scripts': ['demo = yolov5_hse.demo:main']}

setup_kwargs = {
    'name': 'yolov5-hse',
    'version': '0.1.1',
    'description': 'A demo package of a project using Yolov5 model for HSE course',
    'long_description': None,
    'author': 'Berezkin AA HSE',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<3.10',
}


setup(**setup_kwargs)
